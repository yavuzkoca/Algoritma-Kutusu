Since you did not say print function is necessary I didn't
implemented the print function in the examples but I have my own,
it looks better :D You can call it like:

SmallVector a(arr, 10);
a.print();

It also shows size and capacity but I also implemented the get functions.
Kolay gelsin hocam.
